#include "sapi.h"
#include "FreeRTOS.h"
#include "FreeRTOSConfig.h"
#include "task.h"

#define TEST_UART_DELAY_MS 5

void testUpdate (void * taskParmPtr);
